package com.example.weighttracker;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DataDisplayActivity extends AppCompatActivity {

    SQLiteOpenHelper dbHelper;
    SQLiteDatabase db;
    ListView listView;
    Button addDataButton;
    EditText weightInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();

        listView = findViewById(R.id.listViewData);
        addDataButton = findViewById(R.id.btnAddData);
        weightInput = findViewById(R.id.etWeight);

        loadData();

        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addData();
            }
        });
    }

    private void loadData() {
        Cursor cursor = db.rawQuery("SELECT _id, weight FROM weight_data", null);
        String[] from = {"weight"};
        int[] to = {android.R.id.text1};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1, cursor, from, to, 0);
        listView.setAdapter(adapter);
    }

    private void addData() {
        String weight = weightInput.getText().toString();
        if (!weight.isEmpty()) {
            ContentValues values = new ContentValues();
            values.put("weight", weight);
            db.insert("weight_data", null, values);
            Toast.makeText(this, "Weight Added", Toast.LENGTH_SHORT).show();
            loadData();
        } else {
            Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
        }
    }
}
