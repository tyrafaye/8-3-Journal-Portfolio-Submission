package com.example.weighttracker

import android.R
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    var dbHelper: SQLiteOpenHelper? = null
    var db: SQLiteDatabase? = null
    var username: EditText? = null
    var password: EditText? = null
    var loginButton: Button? = null
    var createAccountButton: Button? = null

    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        dbHelper = DatabaseHelper(this)
        db = dbHelper!!.writableDatabase

        username = findViewById(R.id.etUsername)
        password = findViewById(R.id.etPassword)
        loginButton = findViewById(R.id.btnLogin)
        createAccountButton = findViewById(R.id.btnCreateAccount)

        loginButton!!.setOnClickListener {
            val user = username!!.text.toString()
            val pass = password!!.text.toString()
            if (checkUser(user, pass)) {
                val intent: Intent =
                    Intent(
                        this@MainActivity,
                        DataDisplayActivity::class.java
                    )
                ContextCompat.startActivity(intent)
            } else {
                Toast.makeText(
                    this@MainActivity,
                    "Invalid Username or Password",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        createAccountButton!!.setOnClickListener {
            val user = username!!.text.toString()
            val pass = password!!.text.toString()
            addUser(user, pass)
        }
    }

    private fun checkUser(username: String, password: String): Boolean {
        val cursor = db!!.rawQuery(
            "SELECT * FROM users WHERE username=? AND password=?",
            arrayOf(username, password)
        )
        if (cursor.count > 0) {
            cursor.close()
            return true
        }
        cursor.close()
        return false
    }

    private fun addUser(username: String, password: String) {
        db!!.execSQL(
            "INSERT INTO users (username, password) VALUES (?, ?)",
            arrayOf<Any>(username, password)
        )
        Toast.makeText(this, "Account Created", Toast.LENGTH_SHORT).show()
    }
}